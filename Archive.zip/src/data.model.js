import {
  Lang
} from '@/i18n/initI18n';

const i18n = Lang();